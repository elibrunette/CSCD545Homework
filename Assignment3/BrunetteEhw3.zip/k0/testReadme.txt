./jacobi 512 100 1600 1600 p > pout2
./jacobi 0 100 1600 1600 p > sout1

